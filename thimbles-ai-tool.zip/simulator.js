console.log("Simulator running");
// Simulate drawing canvas frames or reading from local data